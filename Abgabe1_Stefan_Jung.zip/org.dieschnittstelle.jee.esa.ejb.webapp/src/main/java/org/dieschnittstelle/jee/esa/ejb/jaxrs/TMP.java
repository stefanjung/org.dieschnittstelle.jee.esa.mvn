package org.dieschnittstelle.jee.esa.ejb.jaxrs;

public class TMP {

}
