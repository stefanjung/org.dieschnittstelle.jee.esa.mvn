package org.dieschnittstelle.jee.esa.entities.crm;

/**
 * see issue: http://jira.codehaus.org/browse/JACKSON-193
 * @author kreutel
 *
 */
public enum Gender {
	
	M, W;
				
}