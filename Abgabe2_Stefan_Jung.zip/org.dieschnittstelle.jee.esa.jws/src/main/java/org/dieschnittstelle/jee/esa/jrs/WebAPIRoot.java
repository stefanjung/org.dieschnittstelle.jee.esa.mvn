package org.dieschnittstelle.jee.esa.jrs;

import javax.ws.rs.core.Application;
import javax.ws.rs.ApplicationPath;;

@ApplicationPath("/api")
public class WebAPIRoot extends Application {

}
